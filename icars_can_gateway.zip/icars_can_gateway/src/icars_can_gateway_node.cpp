/************************************************************************
 * by Salvador Dominguez (from IRCCyN (ECN))
 *
 * Copyright (C) 2014
 *
 * Salvador Dominguez Quijada
 * salvador.dominguez-quijada@irccyn.ec-nantes.fr
 *
 * icars_can_gateway is licenced under the GPL License
 *
 * You are free:
 *   - to Share - to copy, distribute and transmit the work
 *   - to Remix - to adapt the work
 *
 * Under the following conditions:
 *
 *   - Attribution. You may mention the ICARS project and the authors
 *
 *   - Noncommercial. You may not use this work for commercial purposes.
 *
 *   - Share Alike. If you alter, transform, or build upon this work,
 *     you may distribute the resulting work only under the same or
 *     similar license to this one.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 ************************************************************************/

/**
  \file icars_can_gateway.cpp
  \brief node to control the Renault Zoe in ROS
  \author Salvador Dominguez
  \date 25/07/2017
  */

//Semaphores and threads
#include <boost/bind.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread.hpp>

//ROS
#include "ros/ros.h"

//EffiROS
#include "ros_zoe_msgs/CanData.h" //To receive and send the raw CAN topics

#include "ros_zoe_msgs/ControlRefs.h" //!<Input references (steering angle, speed, acceleration and brake strength) in close loop control mode (input topic)

#define MANUAL_MODE             0
#define AUTO_MODE               1
#define COOPERATIVE_MODE        2

//Most relevant CAN BUS IDs
#define CAN_FRONT_WLS               666     //(0x29A) Id of the CAN msg for the front wheels linear speed
#define CAN_REAR_WLS                668     //(0x29C) Id of the CAN msg for the rear wheels linear speed
#define CAN_MOV_DIR                 530     //(0x212) Id of the CAN msg for the sign of the current speed (forward/backward)
#define CAN_STR_ANG                 198     //(0xC6) Id of the CAN msg for the steering angle
#define CAN_BRAKE                   850     //(0x352) Id of the CAN msg for the brake strength
#define CAN_HAND_BRAKE              860     //(0x35C) Id of the CAN msg for the hand brake
#define CAN_BLK_LIGHTS_AND_DOORS    1502    //(0x5DE) Id of the CAN msg for the blinking lights
#define CAN_SEAT_BELT               1619    //(0x653)) Id of the CAN msg for the seat belt check
#define CAN_GEAR                    382     //(0x17E) Id of the CAN msg for the current gear position
#define CAN_AUTONOMY                1620    //(0x654) Id of the CAN msg for the autonomy in km
#define CAN_THROTTLE                390     //(0x186) Id of the CAN msg for the throttle pedal
#define CAN_REAR_PARKING_SENSORS    1513    //!<(0x5E9) Id of the CAN msg for the detection of the rear parking sensors

#define GEAR_SHIFT_POSITION_PARKING 0
#define GEAR_SHIFT_POSITION_REVERSE 1
#define GEAR_SHIFT_POSITION_NEUTRAL 2
#define GEAR_SHIFT_POSITION_DRIVE   3

#define FRONT_LEFT_SEAT_BELT    0
#define FRONT_RIGHT_SEAT_BELT   1
#define REAR_LEFT_SEAT_BELT     2
#define REAR_MIDDLE_SEAT_BELT   3
#define REAR_RIGHT_SEAT_BELT    4

#define BLK_LEFT    0
#define BLK_RIGHT   1

#define OBD_DEV_ID          0 //Id of the Car's CAN bus
//Possible values of the status of the CAN bus device
#define OBD_OK 0
#define OBD_UNAVAILABLE 1


//Namespaces
using namespace std;

ros::Publisher pub_car_data;
ros::Publisher pub_epas_data;

double epas_speed=0.0;

//Callback that receives the CAN ROS topics from ros_zoe_msgs and decodes them to obtain relevant information about the status of the car
void canCarCallback(ros_zoe_msgs::CanData msg_can)
{
    //cout << "Can data comming" << endl;

    /*cout << " can data comming..." << endl;

        cout  << "ID:" << dec << msg_can.id << "[";

        for (unsigned short i=0;i<msg_can.dlc;i++)
        {
            cout << dec  << " " << int(msg_can.data[i]);
        }
        cout << "]" << endl;
    */

    switch(msg_can.id)//Check the identifier of the CAN msg
    {
      case CAN_BLK_LIGHTS_AND_DOORS://Blinking lights
      {
         if (msg_can.data[1]&0x08)//Front left door
         {
            //cout << "FRONT LEFT DOOR OPENED!!!" << endl;
         }

         if (msg_can.data[1]&0x02)//Front right door
         {
            //cout << "FRONT RIGHT DOOR OPENED!!!" << endl;
         }

         if (msg_can.data[2]&0x40)//Rear left door
         {
            //cout << "REAR LEFT DOOR OPENED!!!" << endl;
         }

         if (msg_can.data[2]&0x10)//Rear right door
         {
            //cout << "REAR RIGHT DOOR OPENED!!!" << endl;
         }

         if (msg_can.data[7]&0x10)//Trunk door
         {
            //cout << "TRUNK DOOR OPENED!!!" << endl;
         }

         if (msg_can.data[0]&0x20)//Left side blinking lights
         {
            //cout << "LEFT SIDE BLINKING" << endl;
         }
         else if (msg_can.data[0]&0x40)//Right side blinking lights
         {
            //cout << "RIGHT SIDE BLINKING" << endl;
         }
        }
        break;
      case CAN_FRONT_WLS://Front wheels info. Three values the two first are the speed [Km/h x 200 ] of the two front wheels
        {
           double velFR, velFL;
           unsigned int speed_ui;

           //cout << "front wheels:" << endl;

           //Front-Right speed [km/h]
           velFR=double((static_cast<unsigned short>(msg_can.data[0])<<8)|(static_cast<unsigned short>(msg_can.data[1])))/200.0;
           //Front-Left speed [km/h]
           velFL=double((static_cast<unsigned short>(msg_can.data[2])<<8)|(static_cast<unsigned short>(msg_can.data[3])))/200.0;

           speed_ui=static_cast<unsigned int>(epas_speed)*200.0;
           msg_can.data[0]=(unsigned char)((speed_ui & 0xFF00) >> 8);
           msg_can.data[1]=(unsigned char)(speed_ui & 0x00FF);
           msg_can.data[2]=(unsigned char)((speed_ui & 0xFF00) >> 8);
           msg_can.data[3]=(unsigned char)(speed_ui & 0x00FF);
         }
        break;
      case CAN_REAR_WLS://Rear wheels info. Three values the two first are the speed [Km/h x 200 ] of the two rear wheels
        {
            double velRL, velRR;
            unsigned int speed_ui;

            //Rear-Left speed [Km/h]
            velRL=double((static_cast<unsigned short>(msg_can.data[0])<<8)|(static_cast<unsigned short>(msg_can.data[1])))/200.0;
            //Rear-Right speed [Km/h]
            velRR=double((static_cast<unsigned short>(msg_can.data[2])<<8)|(static_cast<unsigned short>(msg_can.data[3])))/200.0;

            cout << "EPAS speed:" << epas_speed << endl;
            speed_ui=static_cast<unsigned int>(epas_speed)*200.0;
            msg_can.data[0]=(unsigned char)((speed_ui & 0xFF00) >> 8);
            msg_can.data[1]=(unsigned char)(speed_ui & 0x00FF);
            msg_can.data[2]=(unsigned char)((speed_ui & 0xFF00) >> 8);
            msg_can.data[3]=(unsigned char)(speed_ui & 0x00FF);
          }
          break;

      case CAN_BRAKE://Brake strength
        {
          double brakeStrength=double((static_cast<unsigned short>(msg_can.data[3])));
        }
        break;
      case CAN_THROTTLE://Throttle pedal
        {
          //cout << "Throttle" << endl;
          double throttle=double((static_cast<unsigned short>(msg_can.data[5])));
        }
        break;
      case CAN_HAND_BRAKE://Hand brake
        {
          if ((msg_can.data[7]&0x0F)==0x08)
          {
              //cout << "Hand brake ON:" << endl;
          }
        }
        break;
      case CAN_SEAT_BELT://Seat belt check
        {
          if (msg_can.data[1]&0x40)//Front left seat belt
          {
            //cout << "Driver's seat belt NOT fastened!!!!" << endl;
          }
          else
          {
            //cout << "Driver's seat belt fastened" << endl;
          }

          if (msg_can.data[1]&0x10)//There is a passenger in the right seat but it doesn't have the seat belt fastened
          {
            //cout << "Front right seat belt NOT fastened!!!!" << endl;
          }
          else//Either, there is no front right passenger or there is one and it has the seat belt fastened
          {
            //cout << "Front right seat belt fastened" << endl;
          }

          if (msg_can.data[2]&0x80)//Rear left seat belt
          {
            //cout << "Rear right seat belt NOT fastened!!!!" << endl;
          }
          else
          {
            //cout << "Rear right seat belt fastened" << endl;
          }

          if (msg_can.data[1]&0x02)//Rear left seat belt
          {
            //cout << "Rear left seat belt NOT fastened!!!!" << endl;
          }
          else
          {
            //cout << "Rear left seat belt fastened" << endl;
          }

          if (msg_can.data[2]&0x10)//Rear right seat belt
          {
            //cout << "Rear right seat belt NOT fastened!!!!" << endl;
          }
        }
        break;
      case CAN_AUTONOMY://Car autonomy
        {
          unsigned int autonomy=(static_cast<unsigned int>((msg_can.data[5])<<4)&0xf0)|(static_cast<unsigned short>(msg_can.data[6])>>4);
        }
        break;
      case CAN_GEAR://Gear position
        {
          unsigned char gear=((static_cast<unsigned char>(msg_can.data[6])|0x0c)>>4);
        }
        break;
    }
    pub_epas_data.publish(msg_can);
}

//Callback that receives the CAN ROS topics from ros_zoe_msgs and decodes them to obtain relevant information about the status of the car
void canEpasCallback(ros_zoe_msgs::CanData msg_can)
{
    switch(msg_can.id)//Check the identifier of the CAN msg
    {
      case CAN_STR_ANG://Steering angle and angular speed. Two values. First 2 bytes for the steering angle second 2 bytes for the angular speed of the steering angle
        {
            //Prediction of the current steering velocity in deg/sec
            double curr_steer_vel_deg=(double((static_cast<unsigned short>(msg_can.data[2])<<8)|(static_cast<unsigned short>(msg_can.data[3])))-32767.0)/100.0;//Steering angle speed
            double steer_ang_deg=(double((static_cast<unsigned short>(msg_can.data[0])<<8)|(static_cast<unsigned short>(msg_can.data[1])))-32767.0)/100.0;
        }
        break;
    }
    pub_car_data.publish(msg_can);
}

void RefsCallback(ros_zoe_msgs::ControlRefs  msg_ref)
{
    //cout << "Control refs msg comming..." << endl;
    //cout << "Steer ref:" << msg_ref.steerAng << "[deg]" << endl;
    //cout << "Speed ref:" << msg_ref.linSpeed << "[Km/h]" << endl;
    //----------------- SPEED ------------------------
    epas_speed=msg_ref.linSpeed;
}

int main (int argc, char** argv)
{
  //Connect to ROS
  ros::init(argc, argv, "icars_can_gateway");
  ROS_INFO("Node icars_can_gateway Connected to roscore");

  ros::NodeHandle global_nh_;//Local ROS Handler
  ros::NodeHandle local_nh_("~");//Local ROS Handler

  //Publishers
  pub_epas_data=global_nh_.advertise<ros_zoe_msgs::CanData> ("can/data_to_send_to_epas", 1);
  pub_car_data=global_nh_.advertise<ros_zoe_msgs::CanData> ("can/data_to_send_to_car", 1);

  //Subscribers
  ros::Subscriber can_epas_sub=global_nh_.subscribe<ros_zoe_msgs::CanData> ("can/data_read_from_epas", 33, &canEpasCallback);
  ros::Subscriber can_car_sub=global_nh_.subscribe<ros_zoe_msgs::CanData> ("can/data_read_from_car", 33, &canCarCallback);
  ros::Subscriber ref_sub=global_nh_.subscribe<ros_zoe_msgs::ControlRefs> ("control/refs", 1, &RefsCallback);

  ros::spin();

  cout << "Waiting for the CAN bus reader thread to finish..." << endl;

  cout << "EXITING..." << endl;
  ROS_INFO("ROS-Node Terminated\n");
}


